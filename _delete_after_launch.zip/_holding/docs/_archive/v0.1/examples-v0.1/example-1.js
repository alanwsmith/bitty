export class Wrapper {
  $htmlClick(_) {
    return `Clicked at: ${Date.now()}`;
  }
}
