// deno-fmt-ignore-file


export default class {
  init() {
    this.bridge.innerHTML = "This is from init() in Wires";
  }

}
